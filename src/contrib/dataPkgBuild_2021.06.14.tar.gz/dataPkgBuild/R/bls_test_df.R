#' BLS API Data
#'
#' A dataset from bls API
#'
#' @source \url{https://www.bls.gov}
#'
"bls_test_df"

